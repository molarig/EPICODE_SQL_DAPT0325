##TASK 3) Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate)
CREATE DATABASE toysgroup;
USE toysgroup;
SHOW TABLES;

DESCRIBE TABLE product;
DESCRIBE TABLE region;
DESCRIBE TABLE sales;

SELECT * FROM product;
SELECT * FROM region;
SELECT * FROM sales;


CREATE TABLE product (
	product_id INT AUTO_INCREMENT PRIMARY KEY,
    productname VARCHAR (50),
    category VARCHAR (50),
    listprice DECIMAL (10,2)
);

INSERT INTO product (productname, category, listprice)
VALUES
	('Speed Racer Car','Vehicles','52.12'),
	('Wildlife Safari Set','Educational','24.56'),
	('Castle Adventure','Building Blocks','89.32'),
	('Ocean Explorer Boat','Vehicles','74.23'),
	('Classic Teddy Bear','Plush','15.45'),
	('Rainbow Puzzle','Puzzles','8.89'),
	('Dance Party Mat','Musical Toys','26.23'),
	('Magic Art Station','Arts & Crafts','32.78'),
	('Dino World Model','Action Figures','35.89'),
	('My First Kitchen','Pretend Play','80.36'),
	('Star Explorer Rocket','Vehicles','65.78'),
	('City Police Set','Building Blocks','45.45'),
	('Alphabet Cubes','Educational','18.78'),
	('Bubble Maker Gun','Outdoor','5.89'),
	('Pirate Ship Set','Action Figures','55.89'),
	('Fairy Garden Kit','Arts & Crafts','29.35'),
	('Jungle Drum','Musical Toys','30.46'),
	('Racing Team Track','Vehicles','61.54'),
	('Space Puzzle','Puzzles','18.5'),
	('Farm Animal Friends','Plush','22.9');

CREATE TABLE region (
	region_id INT AUTO_INCREMENT PRIMARY KEY,
    region VARCHAR (50),
    country VARCHAR (50)
);

INSERT INTO region (country, region)
VALUES
	('Sweden','North Europe'),
	('Norway','North Europe'),
	('Denmark','North Europe'),
	('Germany','West Europe'),
	('France','West Europe'),
	('Netherlands','West Europe'),
	('Italy','South Europe'),
	('Spain','South Europe'),
	('Greece','South Europe'),
	('Poland','East Europe'),
	('Czech Republic','East Europe'),
	('Hungary','East Europe'),
	('United States','North America'),
	('Canada','North America'),
	('Brazil','Latin America'),
	('Mexico','Latin America'),
	('China','Asia Pacific'),
	('Japan','Asia Pacific'),
	('United Arab Emirates','Middle East'),
	('South Africa','Africa');

CREATE TABLE sales (
	sales_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    region_id INT,
    salesdate DATE,
    quantity INT
);

INSERT INTO sales (product_id, region_id, salesdate, quantity)
VALUES
	(1,4,'2023-01-10',110),
	(3,7,'2023-01-22',95),
	(2,5,'2023-02-15',78),
	(5,9,'2023-03-10',130),
	(8,15,'2023-04-12',60),
	(6,12,'2023-05-20',90),
	(1,4,'2023-06-25',88),
	(7,5,'2023-07-29',140),
	(9,13,'2023-08-07',115),
	(10,19,'2023-09-18',72),
	(4,17,'2023-10-30',75),
	(11,8,'2023-11-15',130),
	(3,7,'2024-01-05',105),
	(12,11,'2024-02-16',95),
	(13,2,'2024-03-12',100),
	(14,20,'2024-04-15',125),
	(15,8,'2024-05-20',70),
	(16,18,'2024-06-23',110),
	(17,16,'2024-07-29',60),
	(18,14,'2024-08-14',83),
	(19,18,'2024-09-10',120),
	(20,1,'2024-10-31',95),
	(1,4,'2024-11-18',80),
	(2,5,'2025-01-04',110),
	(3,7,'2025-02-12',90),
	(4,17,'2025-03-25',135),
	(5,9,'2025-04-10',96),
	(6,12,'2025-05-17',88),
	(7,5,'2025-06-05',115),
	(8,15,'2025-07-01',78),
	(9,13,'2025-07-21',90),
	(10,19,'2025-08-11',102),
	(11,8,'2025-08-29',105),
	(12,11,'2025-09-23',95),
	(13,2,'2025-10-10',84),
	(14,20,'2025-10-30',132),
	(15,8,'2023-01-15',75),
	(16,18,'2023-02-08',110),
	(17,16,'2023-03-14',78),
	(18,14,'2023-04-25',108),
	(19,18,'2023-05-19',105),
	(20,1,'2023-06-14',80),
	(1,4,'2023-07-23',111),
	(2,7,'2023-08-15',92),
	(3,5,'2023-09-28',85),
	(4,17,'2023-10-30',130),
	(5,9,'2024-11-12',60),
	(6,12,'2024-12-05',128),
	(7,5,'2025-01-28',138),
	(8,15,'2025-02-25',79);
    
#rimuovo dalla tabella i record con product_id = 17 per avere almeno 1 prodotto che non è stato mai venduto, ai fini del corretto svolgimento dell'esercizio.
START TRANSACTION;
DELETE FROM sales
WHERE product_id = 17;
SELECT * FROM sales;
COMMIT;
    
ALTER TABLE sales
ADD CONSTRAINT fk_sales_product
FOREIGN KEY (product_id) REFERENCES product(product_id),
ADD CONSTRAINT fk_sales_region
FOREIGN KEY (region_id) REFERENCES region(region_id);

##TASK 4
#1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).
SELECT product_id, productname, COUNT(product_id) AS occorrenze
FROM product
GROUP BY product_id
HAVING occorrenze > 1;

SELECT region_id, country, COUNT(region_id) AS occorrenze
FROM region
GROUP BY region_id
HAVING occorrenze > 1;

SELECT *, COUNT(sales_id) AS occorrenze
FROM sales
GROUP BY sales_id
HAVING occorrenze > 1;

#2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita
#e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT s.sales_id, s.salesdate, p.productname, p.category, r.country, r.region,
	CASE 
           WHEN DATEDIFF(CURDATE(), salesdate) > 180 THEN 'True'
           ELSE 'False'
       END AS is_older_than_180_days
FROM sales s
LEFT JOIN product p
ON p.product_id = s.product_id
LEFT JOIN region r
ON r.region_id = s.region_id;

#3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito.
#(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.

SELECT product_id, SUM(quantity) AS totalquantity
FROM sales
WHERE YEAR(salesdate) = (
	SELECT MAX(YEAR(salesdate))
	FROM sales
    )
GROUP BY product_id
HAVING totalquantity > (
	SELECT AVG(quantity)
	FROM sales
	WHERE YEAR(salesdate) = (
		SELECT MAX(YEAR(salesdate))
		FROM sales
	)
);

#4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT p.product_id, p.productname, YEAR(s.salesdate) AS salesyear, SUM(listprice*quantity) AS totalsales
FROM product p
JOIN sales s
ON p.product_id = s.product_id
GROUP BY p.product_id, p.productname, YEAR(salesdate)
ORDER BY p.product_id;

#5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT r.country, YEAR(s.salesdate) AS salesyear, SUM(listprice*quantity) AS totalsales
FROM region r
JOIN sales s
ON r.region_id = s.region_id
JOIN product p
ON p.product_id = s.product_id
GROUP BY r.country, YEAR(salesdate)
ORDER BY YEAR(s.salesdate), totalsales DESC;

#6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT p.category, SUM(s.quantity) AS quantity
FROM product p
JOIN sales s
ON p.product_id = s.product_id
GROUP BY p.category
ORDER BY quantity DESC
LIMIT 1;

#7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
#Approccio 1
SELECT p.product_id, p.productname
FROM product p
LEFT JOIN sales s ON p.product_id = s.product_id
WHERE s.sales_id IS NULL;

#Approccio 2
SELECT product_id, productname
FROM product
WHERE product_id NOT IN (
    SELECT DISTINCT product_id
    FROM sales
);

#8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
#NOTA: la tabella product contiene già le informazioni richieste dalla consegna, ma creo comunque una View in modo da rispondere alla consegna come richiesto.

CREATE VIEW prodotti_denormalizzata
AS (
	SELECT
		product_id AS codice_prodotto,
		productname AS nome_prodotto,
		category AS categoria_prodotto
	FROM product
);
    
SELECT * from prodotti_denormalizzata;

#Se avessi avuto le categorie in un'altra tabella 'category' avrei fatto così (ovviamente questa query non funzionerà):
CREATE VIEW product_denormalized AS
SELECT
    p.product_id,
    p.productname,
    c.category_name
FROM product p
JOIN category c
ON p.category_id = c.category_id;

#9)	Creare una vista per le informazioni geografiche
#NOTA: come sopra, la tabella region contiene già le informazioni richieste dalla consegna, ma creo comunque una View.

CREATE VIEW paesi_denormalizzata
AS (
	SELECT
		region_id AS codice_regione,
		country AS paese,
		region AS regione
	FROM region
);
    
SELECT * from paesi_denormalizzata;

#Se avessi avuto le aree in un'altra tabella 'area', avrei fatto così (anche questa query non funzionerà):
CREATE VIEW paesi_denormalized AS
SELECT
    r.region_id,
    r.region,
    a.area_name
FROM region r
JOIN area a
ON r.area_id = a.area_id;